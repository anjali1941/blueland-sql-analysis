DROP VIEW IF EXISTS Top3ProductsByCategory;
GO

CREATE VIEW Top3ProductsByCategory AS
WITH RevenueData AS (
    SELECT 
        p.ProductName,
        p.Category,
        SUM(od.TotalAmount) AS TotalRevenue
    FROM 
        dbo.XL_Products p
    JOIN 
        dbo.XL_OrderDetails od ON p.ProductID = od.ProductID
    GROUP BY 
        p.ProductName, p.Category
)
SELECT 
    ProductName,
    Category,
    TotalRevenue,
    RANK() OVER (PARTITION BY Category ORDER BY TotalRevenue DESC) AS RevenueRank
FROM 
    RevenueData
    GO
    SELECT *
FROM Top3ProductsByCategory
WHERE RevenueRank <= 3




