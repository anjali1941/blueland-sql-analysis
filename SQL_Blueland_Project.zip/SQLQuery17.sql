SELECT 
    p.ProductName,
    p.Category,
    SUM(od.TotalAmount) AS TotalRevenue
FROM 
    XL_OrderDetails od
JOIN 
    XL_Products p ON od.ProductID = p.ProductID
GROUP BY 
    p.ProductName, p.Category