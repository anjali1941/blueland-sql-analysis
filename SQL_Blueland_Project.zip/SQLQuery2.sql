--DROP TABLE IF EXISTS Customers
--DROP TABLE IF EXISTS Products
--Question:1 Who are our customers from India, and when did they join?
 SELECT 
    CustomerID,
    CustomerName,
    Country,
    JoinDate
    FROM 
    XL_Customers
WHERE 
    Country = 'India'
ORDER BY 
    JoinDate DESC
-- Question:2 How many unique countries do our customers come from?
SELECT DISTINCT Country AS UniqueCountryName
FROM XL_Customers;
--Question:3: Which customers have placed more than 5 orders?
SELECT 
    c.CustomerID,
    c.CustomerName,
    COUNT(o.OrderID) AS TotalOrders
FROM 
    XL_Customers AS c
JOIN 
    XL_Orders AS o
    ON c.CustomerID = o.CustomerID
GROUP BY 
    c.CustomerID, c.CustomerName
HAVING 
    COUNT(o.OrderID) > 5
ORDER BY 
    TotalOrders DESC;
    --Question: Orders in 2023, Electronics/Fitness category, missing description
   SELECT 
    o.OrderID,
    o.OrderDate,
    p.ProductName,
    p.Category
FROM XL_Orders AS o
JOIN XL_OrderDetails AS oi ON o.OrderID = oi.OrderID
JOIN XL_Products AS p ON oi.ProductID = p.ProductID
WHERE 
    o.OrderDate BETWEEN '2023-01-01' AND '2023-12-31'
    AND p.Category IN ('Accessories', 'Sherwanis')
ORDER BY o.OrderDate
--Question:5: Total revenue by product in 2023
SELECT 
    p.ProductName,
    p.Category,
   SUM(oi.TotalAmount) AS TotalRevenue,
    COUNT(*) AS TotalItemsSold
FROM XL_Orders AS o
JOIN XL_OrderDetails AS oi ON o.OrderID = oi.OrderID
JOIN XL_Products AS p ON oi.ProductID = p.ProductID
WHERE 
    o.OrderDate BETWEEN '2023-01-01' AND '2023-12-31'
GROUP BY 
    p.ProductName, p.Category
ORDER BY 
    TotalRevenue DESC
    --Question:6: Average spend per order
    SELECT 
    AVG(OrderTotal) AS AvgSpend,
    MAX(OrderTotal) AS MaxSpend,
    MIN(OrderTotal) AS MinSpend
FROM (
    SELECT 
        o.OrderID,
        SUM(TotalAmount) AS OrderTotal
    FROM XL_Orders AS o
    JOIN XL_OrderDetails AS oi ON o.OrderID = oi.OrderID
    WHERE 
        o.OrderDate BETWEEN '2023-01-01' AND '2023-12-31'
    GROUP BY o.OrderID
) AS OrderSummary
--Question:7: Products with revenue above average using subquery
SELECT 
    p.ProductName,
    p.Category,
    SUM(od.TotalAmount) AS TotalRevenue
FROM XL_OrderDetails od
JOIN XL_Products p ON od.ProductID = p.ProductID
JOIN XL_Orders o ON od.OrderID = o.OrderID
WHERE o.OrderDate BETWEEN '2023-01-01' AND '2023-12-31'
GROUP BY p.ProductName, p.Category
HAVING SUM(od.TotalAmount) > (
    SELECT AVG(TotalRevenue)
    FROM (
        SELECT 
            ProductID,
            SUM(TotalAmount) AS TotalRevenue
        FROM XL_OrderDetails
        GROUP BY ProductID
    ) AS ProductSummary
)
ORDER BY TotalRevenue DESC;
--Question:8: Classify customers into spending tiers using CASE WHEN
SELECT 
    c.CustomerID,
    c.CustomerName,
    SUM(od.TotalAmount) AS TotalSpent,
    CASE 
        WHEN SUM(od.TotalAmount) > 200000 THEN 'High Spender'
        WHEN SUM(od.TotalAmount) BETWEEN 100000 AND 200000 THEN 'Medium Spender'
        ELSE 'Low Spender'
    END AS SpendingTier
FROM 
    XL_Customers c
JOIN 
    XL_Orders o ON c.CustomerID = o.CustomerID
JOIN 
    XL_OrderDetails od ON o.OrderID = od.OrderID
GROUP BY 
    c.CustomerID, c.CustomerName
ORDER BY 
    TotalSpent DESC;
    --Question:9: product categories perform best in each quarter of the year
  WITH RevenueByQuarter AS (
    SELECT 
        YEAR(o.OrderDate) AS OrderYear,
        DATEPART(QUARTER, o.OrderDate) AS OrderQuarter,
        p.Category,
        SUM(od.TotalAmount) AS TotalRevenue
    FROM 
        XL_Orders o
    JOIN 
        XL_OrderDetails od ON o.OrderID = od.OrderID
    JOIN 
        XL_Products p ON od.ProductID = p.ProductID
    WHERE 
        o.OrderDate IS NOT NULL
    GROUP BY 
        YEAR(o.OrderDate),
        DATEPART(QUARTER, o.OrderDate),
        p.Category
),
RankedRevenue AS (
    SELECT *,
           RANK() OVER (PARTITION BY OrderYear, OrderQuarter ORDER BY TotalRevenue DESC) AS rnk
    FROM RevenueByQuarter
)
SELECT 
    OrderYear,
    OrderQuarter,
    Category,
    TotalRevenue
FROM RankedRevenue
WHERE rnk = 1
ORDER BY OrderYear, OrderQuarter;
--Question:10:Categories in 2022 but not in 2023
SELECT DISTINCT p.Category
FROM XL_Orders o
JOIN XL_OrderDetails od ON o.OrderID = od.OrderID
JOIN XL_Products p ON od.ProductID = p.ProductID
WHERE YEAR(o.OrderDate) = 2022

EXCEPT

SELECT DISTINCT p.Category
FROM XL_Orders o
JOIN XL_OrderDetails od ON o.OrderID = od.OrderID
JOIN XL_Products p ON od.ProductID = p.ProductID
WHERE YEAR(o.OrderDate) = 2023
-- New categories that appeared in 2023 but not in 2022
SELECT DISTINCT p.Category
FROM dbo.XL_Orders o
JOIN dbo.XL_OrderDetails od ON o.OrderID = od.OrderID
JOIN dbo.XL_Products p ON od.ProductID = p.ProductID
WHERE YEAR(o.OrderDate) = 2023

EXCEPT

SELECT DISTINCT p.Category
FROM dbo.XL_Orders o
JOIN dbo.XL_OrderDetails od ON o.OrderID = od.OrderID
JOIN dbo.XL_Products p ON od.ProductID = p.ProductID
WHERE YEAR(o.OrderDate) = 2022

--Top 3 Products by Revenue per Category
;WITH ProductRevenue AS (
    SELECT 
        p.ProductName,
        p.Category,
        SUM(od.TotalAmount) AS TotalRevenue,
        ROW_NUMBER() OVER (
            PARTITION BY p.Category 
            ORDER BY SUM(od.TotalAmount) DESC
        ) AS RevenueRank
    FROM dbo.XL_Products p
    JOIN dbo.XL_OrderDetails od ON p.ProductID = od.ProductID
    GROUP BY p.ProductName, p.Category
)
--Month-over-Month Revenue Growth by Category

SELECT *
FROM ProductRevenue
WHERE RevenueRank <= 3
ORDER BY Category, RevenueRank

SELECT
    YEAR(o.OrderDate) AS OrderYear,
    MONTH(o.OrderDate) AS OrderMonth,
    p.Category,
    ROUND(SUM(od.TotalAmount), 2) AS TotalRevenue,
    ROUND(LAG(SUM(od.TotalAmount)) OVER (PARTITION BY p.Category ORDER BY YEAR(o.OrderDate), MONTH(o.OrderDate)), 2) AS PrevMonthRevenue,
    ROUND(
        (SUM(od.TotalAmount) - LAG(SUM(od.TotalAmount)) OVER (PARTITION BY p.Category ORDER BY YEAR(o.OrderDate), MONTH(o.OrderDate)))
        / NULLIF(LAG(SUM(od.TotalAmount)) OVER (PARTITION BY p.Category ORDER BY YEAR(o.OrderDate), MONTH(o.OrderDate)), 0) * 100
    , 2) AS MoM_Growth_Percent
FROM
    XL_Orders o
JOIN
    XL_OrderDetails od ON o.OrderID = od.OrderID
JOIN
    XL_Products p ON od.ProductID = p.ProductID
GROUP BY
    YEAR(o.OrderDate),
    MONTH(o.OrderDate),
    p.Category
ORDER BY
    OrderYear, OrderMonth, p.Category
   -- total revenue generated per product per year, and compare year-over-year performance.
    SELECT 
    p.ProductName,
    YEAR(o.OrderDate) AS OrderYear,
    SUM(od.TotalAmount) AS TotalRevenue,
    LAG(SUM(od.TotalAmount)) OVER (PARTITION BY p.ProductName ORDER BY YEAR(o.OrderDate)) AS PreviousYearRevenue,
    ROUND(
        (SUM(od.TotalAmount) - LAG(SUM(od.TotalAmount)) OVER (PARTITION BY p.ProductName ORDER BY YEAR(o.OrderDate))) 
        / NULLIF(LAG(SUM(od.TotalAmount)) OVER (PARTITION BY p.ProductName ORDER BY YEAR(o.OrderDate)), 0) * 100, 2
    ) AS YoY_Growth_Percent
FROM dbo.XL_Orders o
JOIN dbo.XL_OrderDetails od ON o.OrderID = od.OrderID
JOIN dbo.XL_Products p ON od.ProductID = p.ProductID
GROUP BY p.ProductName, YEAR(o.OrderDate)
ORDER BY p.ProductName, OrderYear;
--Nested Subqueries with Filtering
SELECT 
    c.CustomerID,
    c.CustomerName,
    COUNT(DISTINCT o.OrderID) AS TotalOrders,
    SUM(od.TotalAmount) AS TotalSpent
FROM 
    XL_Customers c
JOIN 
    XL_Orders o ON c.CustomerID = o.CustomerID
JOIN 
    XL_OrderDetails od ON o.OrderID = od.OrderID
GROUP BY 
    c.CustomerID, c.CustomerName
HAVING 
    COUNT(DISTINCT o.OrderID) > (
        SELECT AVG(OrderCount)
        FROM (
            SELECT CustomerID, COUNT(DISTINCT OrderID) AS OrderCount
            FROM XL_Orders
            GROUP BY CustomerID
        ) AS OrderCounts
    )
    AND
    SUM(od.TotalAmount) > (
        SELECT AVG(CustomerSpending)
        FROM (
            SELECT o.CustomerID, SUM(od.TotalAmount) AS CustomerSpending
            FROM XL_Orders o
            JOIN XL_OrderDetails od ON o.OrderID = od.OrderID
            GROUP BY o.CustomerID
        ) AS SpendingTotals
    )
