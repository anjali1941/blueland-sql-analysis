CREATE NONCLUSTERED INDEX idx_ProductID_OrderDetails
ON XL_OrderDetails(ProductID)
CREATE NONCLUSTERED INDEX idx_Category_ProductName
ON XL_Products(Category, ProductName)